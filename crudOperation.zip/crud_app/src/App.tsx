import React from "react";
import "./App.css";
import StudentPage from "./Component/Student/StudentPage";

class App extends React.Component<any> {
  render() {
    return (
      <div className="App">
        <StudentPage />
      </div>
    );
  }
}
export default App;
