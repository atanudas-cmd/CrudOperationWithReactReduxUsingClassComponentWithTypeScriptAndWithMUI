import { STUDENT_ADD, STUDENT_EDIT, STUDENT_DELETE, STUDENT_UPDATE_INDEX, STUDENT_POP_OPEN, STUDENT_POP_CLOSE } from "./StudentActionType";

/*
1.  localStorage.getItem("transactions"): This line checks if there is a value stored in the browser's
 localStorage with the key "transactions". The getItem method retrieves the value associated with the specified key.
  == null: This is a comparison operator that checks if the value retrieved from localStorage is null, 
  meaning that no value has been previously stored for the "transactions" key.

2.localStorage.setItem("transactions", JSON.stringify([])): If the value is null (indicating no previous transactions), 
this line sets the "transactions" key in localStorage with a new value. The setItem method assigns a value to a specified key. 
In this case, it assigns an empty array [] after converting it to a string using JSON.stringify. Storing an empty array allows 
for future additions of transactions to this array.
*/
if (localStorage.getItem("transactions") == null)
  localStorage.setItem("transactions", JSON.stringify([]));

/*
In summary, the initialState object is used to define the initial state of a component or application, 
with properties that store information about the current index, a list of transactions retrieved from localStorage, 
and a flag indicating whether something is open or not.
*/
let initialState = {
    currentIndex: -1,  //This property represents the current index and is set to -1 initially. It indicates that no specific index is selected or active.
    list: JSON.parse(localStorage.getItem("transactions") || "{}"),    //The getItem method retrieves the value associated with the specified key, and JSON.parse is used to convert the retrieved value from a JSON string into an object.
    is_open: false,  //indicating that nothing is open.
};

export const StudentReducer = (state: any = initialState, action: any) => {      // The reducer function takes two parameters: state and action. The state parameter represents the current state of the application, and action represents the action object dispatched to update the state.
  
  const list = JSON.parse(localStorage.getItem("transactions") || "{}");

  switch (action.type) {

    case STUDENT_ADD:    //case STUDENT_ADD: This line represents a case in a switch statement where the action type is STUDENT_ADD. It indicates that this block of code will be executed when an action of type STUDENT_ADD is dispatched.
      list.push(action.payload);   //list.push(action.payload): This line appends the action.payload (which likely contains student data) to the list array. It modifies the list array by adding the new student data to the end of the array.
      localStorage.setItem("transactions", JSON.stringify(list));   //localStorage.setItem("transactions", JSON.stringify(list)): This line updates the localStorage value for the key "transactions" by converting the list array to a JSON string using JSON.stringify. The setItem method then stores the JSON string as the new value for the "transactions" key in localStorage. This allows the updated list of transactions to be saved in the browser's storage.
      return {list, currentIndex: -1};   //This line returns a new state object with two properties: list and currentIndex. The list property contains the updated array after adding the new student data, and currentIndex is set to -1. This signifies that no specific index is currently selected or active.

    case STUDENT_EDIT:
      list[state.currentIndex] = action.payload;    //list[state.currentIndex] = action.payload;: This line updates the list array at the index specified by state.currentIndex with the action.payload value. It replaces the existing student data at that index with the updated student data provided in the payload of the action.
      localStorage.setItem("transactions", JSON.stringify(list));
      return {
        list,
        currentIndex: -1
      };

/*
when the STUDENT_UPDATE_INDEX action is dispatched, this code block returns a new state object with the same list array and updates the currentIndex property with the value provided in the action's payload. This action is typically used to update the currently selected or active index in the list of students.
*/
    case STUDENT_UPDATE_INDEX:
      return {
        list,
        currentIndex: action.payload
      };

    case STUDENT_DELETE:
      list.splice(action.payload, 1);   //This line modifies the list array by using the splice() method. It removes one element from the list array at the index specified by action.payload. The splice() method mutates the original array by removing or replacing elements.
      localStorage.setItem("transactions", JSON.stringify(list));
      return {
        list,
        currentIndex: -1
      };

    case STUDENT_POP_OPEN:
      return {
        ...state,
        is_open: true,
      };

    case STUDENT_POP_CLOSE:
      return {
        ...state,
        is_open: false,
      };

    default:
      return state;
  }
};

export default StudentReducer;
