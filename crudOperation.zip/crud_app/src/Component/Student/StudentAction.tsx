import { STUDENT_ADD, STUDENT_EDIT, STUDENT_DELETE, STUDENT_UPDATE_INDEX, STUDENT_POP_OPEN, STUDENT_POP_CLOSE } from "./StudentActionType";


/*
 This line exports a function named studentDataAdd as an action creator. It takes data as a parameter, which represents the student data to be added to the store. It also takes dispatch as a parameter, which is a function provided by the Redux store to dispatch actions.
*/
/*
This line dispatches an action by calling the dispatch function provided as a parameter. The dispatched action is an object with the following properties:
   type:: STUDENT_ADD: This property specifies the type of the action, which is STUDENT_ADD. It indicates that this action represents the addition of student data.
   payload:: data: This property contains the data parameter passed to the studentDataAdd function. It represents the student data that will be added to the store.
*/
export const studentDataAdd = (data: any) => (dispatch: any) => {
  return dispatch({
    type: STUDENT_ADD,
    payload: data,
  });
};

export const update = (data: any) => (dispatch: any) => {
  return dispatch({
    type: STUDENT_EDIT,
    payload: data,
  });
};

export const Delete = (id: any) => (dispatch: any) => {
  return dispatch({
    type: STUDENT_DELETE,
    payload: id,
  });
};

export const updateIndex = (index: any) => (dispatch: any) => {
  return dispatch({
    type: STUDENT_UPDATE_INDEX,
    payload: index,
  });
};

export const popupOpen = () => (dispatch: any) => {
  return dispatch({
    type: STUDENT_POP_OPEN,
  })
};

export const popupClose = () => (dispatch: any) => {
  return dispatch({
    type: STUDENT_POP_CLOSE,
  });
};
