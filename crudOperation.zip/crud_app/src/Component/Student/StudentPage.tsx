import React, { Component } from "react";
import { connect, ConnectedProps } from "react-redux";
import { updateIndex, Delete, popupOpen, popupClose } from "./StudentAction";
import { Button, Typography } from "@mui/material";
import { Box } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import { DataGrid, GridColDef } from "@mui/x-data-grid";
import Divider from "@mui/material/Divider";
import StudentPopup from "./StudentPopup";
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

class StudentPage extends Component<any, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      open: false,
      number1: 0
    };
  }
  /*
1. const { popupOpen, updateIndex } = this.props;: This line uses destructuring assignment to extract the popupOpen and updateIndex functions from the props object of the component. These functions are expected to be passed as props to the component from its parent component.
2. updateIndex(index - 1);: This line calls the updateIndex function, passing index - 1 as the argument. It is assumed that the updateIndex function is responsible for updating the index value in the component's state or triggering an action to update the index in the Redux store. Subtracting 1 from the index suggests that the index is zero-based.
3. popupOpen();: This line invokes the popupOpen function. It is likely that the popupOpen function is responsible for opening a popup or triggering an action related to displaying a student editing form or modal. The specific implementation of the popupOpen function is not shown in the code snippet provided.
  */
  handleEdit = (index: any) => {
    const { popupOpen, updateIndex } = this.props;
    updateIndex(index - 1);
    popupOpen();
  };

  /*
  when a student's delete button is clicked. It calls the Delete function to delete the student data based on the provided index and then triggers the popupClose function to close any related popups or dialogs associated with the deletion process.
  */
  handleDelete = (index: any) => {
    const { popupClose, Delete } = this.props;
    Delete(index);
    popupClose();
    this.handleClose1()

  };

  handleClickOpen1 = (index: any) => {
    this.setState({ open: true });
  };

  handleClose1 = () => {
    this.setState({ open: false });
  };

  columns: GridColDef[] = [
    { field: "id", headerName: "ID", width: 116 },
    {
      field: "fname",
      headerName: "First name",
      width: 230,
      editable: true,
    },
    {
      field: "lname",
      headerName: "Last name",
      width: 230,
      editable: true,
    },
    {
      field: "email",
      headerName: "Email",
      width: 290,
    },
    {
      field: "mobile",
      headerName: "Mobile",
      width: 260,
    },
    {
      field: "Action",
      headerName: "Action",
      headerAlign: "center",
      width: 300,

      renderCell: (params: any) => (
        <div style={{ fontSize: 25 }}>
          <Button
            variant="contained"
            size="small"
            sx={{ m: 7 }}
            onClick={() => {
              this.handleEdit(params.id);
            }}
          >
            <EditIcon />
          </Button>

          <Button
            variant="contained"
            size="small"
            sx={{}}
            onClick={() => {
              this.handleClickOpen1(params)
              this.setState({ number1: params.id - 1 })
              // this.handleDelete(params.id - 1);
            }}
          >
            <DeleteIcon />
          </Button>
        </div>
      ),
    },
  ];

  render() {
    // console.log(this.state.number1)
    const { number1 } = this.state
    /*const { list } = this.props.student;: This line extracts the list property from the student object in the component's props using 
    destructuring assignment. It assumes that the student object is passed as a prop to the component and contains the list property, 
    which represents an array of student data.
    */
    const { list } = this.props.student;
    const { open } = this.state;
    /*
    1. This line creates a new array named rows by mapping over the list array. The map function is called on the list array,
    and for each item in the array, a new object is created.
    2. (item: any, index: any) => ({ id: index + 1, ...item }): This part represents the mapping function. It takes two parameters, 
    item and index, which represent the current item and index within the list array. It creates a new object that contains the properties
     from the item object spread using the spread syntax (...item). Additionally, it adds an id property to each object with a value equal 
     to the index plus 1 (index + 1). The index + 1 is used to create a unique identifier for each row.
      The resulting objects are collected into a new array, which is assigned to the rows variable.
    */
    const rows = list.map((item: any, index: any) => ({ id: index + 1, ...item }));
    return (
      <div>
        <Divider>
          <Typography variant="h3" component="h3" color="primary"> Crud Operation </Typography>
        </Divider>
        <StudentPopup />
        <br />
        <Box sx={{ height: 500, width: "90%", m: 8 }}>
          <DataGrid
            rows={rows}
            sx={{ color: "primary.main", fontSize: 22 }}
            columns={this.columns}
            initialState={{
              pagination: {
                paginationModel: {
                  pageSize: 7,
                },
              },
            }}
            pageSizeOptions={[7]}
            disableRowSelectionOnClick
          />
        </Box>
        <Box >
          <Dialog
            open={open}
            onClose={this.handleClose1}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
          >
            <DialogTitle id="alert-dialog-title">{'Confirm the action'}</DialogTitle>
            <DialogContent>
              <DialogContentText id="alert-dialog-description">
                {'Do you want to delete the data ? Are you sure !'}
              </DialogContentText>
            </DialogContent>
            <DialogActions>
              <Button variant="contained" onClick={this.handleClose1} >Disagree</Button>
              <Button variant="contained" onClick={(e) => this.handleDelete(number1)} autoFocus>Agree</Button>
            </DialogActions>
          </Dialog>
        </Box>

      </div>
    );
  }
}

const mapStateToProps = (state: any) => {
  const student = state.student; //This line extracts the student property from the Redux state object. 
  return {
    student: student,  //student assigns the student property extracted from the state to a prop named student. This makes the student property available as a prop within the component.
    is_open: student.is_open, //This implies that the student slice of the state has a property called is_open, and it is being mapped to the is_open prop.
  };
};

const mapDispatchToProps = {
  updateIndex,
  Delete,
  popupOpen,
  popupClose,
};

const connector = connect(mapStateToProps, mapDispatchToProps);

type PropsFromRedux = ConnectedProps<typeof connector>;

type Props = PropsFromRedux;

export default connector(StudentPage); 
