import React, { Component } from "react";
import { connect,ConnectedProps } from "react-redux";
import { studentDataAdd, updateIndex, update, popupOpen, popupClose } from "./StudentAction";
import Button from "@mui/material/Button";
import { Dialog, DialogTitle, Typography } from "@mui/material";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import { Grid, TextField } from "@mui/material";

class StudentPopup extends Component<any> {
  state = {
    ...this.returnStateObject(),
  };

  returnStateObject() {
    if (this.props.currentIndex === -1)
      return {
        fname: "",
        lname: "",
        email: "",
        mobile: "",
      } 
      else   {
      return this.props.list[this.props.currentIndex];
    }
  }

  componentDidUpdate(prevProps: any) {
    if ( prevProps.currentIndex !== this.props.currentIndex || prevProps.list.length !== this.props.list.length)
     {
      this.setState({ ...this.returnStateObject() });
    }
  }

  handleInputChange = (e: any) => {
    this.setState({
      [e.target.name]: e.target.value,
    });
  };

  handleSubmit = (e: any) => {
    e.preventDefault();
    this.hide();
    if (this.props.currentIndex === -1) {
      this.props.studentDataAdd(this.state);
    } else {
      const { popupClose, update, updateIndex, currentIndex } = this.props;
      updateIndex(currentIndex);
      popupClose(currentIndex);
      update(this.state);
    }
  };

  show = () => {
    const { popupOpen } = this.props;
    popupOpen();
  };

  hide = () => {
    const { updateIndex } = this.props;
    updateIndex(-1);
  };

  render() {
    const { is_open } = this.props;

    return (
      <>
        <Button variant="contained" onClick={this.show} sx={{ mt: 4, ml: 157 }}>Add Student</Button>

        <Dialog open={is_open} maxWidth="sm">
          <DialogTitle style={{ textAlign: "center" }}>
            <Typography color="primary" fontSize={"25px"}> Register </Typography>
          </DialogTitle>
          
          <DialogContent dividers>
            <form onSubmit={this.handleSubmit} autoComplete="off">
              <Grid container>
                <Grid item xs={12}>
                  <TextField
                    margin="dense"
                    fullWidth
                    name="fname"
                    label="First name"
                    variant="standard"
                    onChange={this.handleInputChange}
                    value={this.state.fname}
                  />
                  <br />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    margin="dense"
                    fullWidth
                    name="lname"
                    label="Last name"
                    variant="standard"
                    onChange={this.handleInputChange}
                    value={this.state.lname}
                  />
                  <br />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    margin="dense"
                    fullWidth
                    name="email"
                    label="Email"
                    variant="standard"
                    onChange={this.handleInputChange}
                    value={this.state.email}
                  />
                  <br />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    type="number"
                    margin="dense"
                    fullWidth
                    name="mobile"
                    variant="standard"
                    label="Mobile"
                    onChange={this.handleInputChange}
                    value={this.state.mobile}
                  />
                  <br />
                </Grid>
                <DialogActions>
                  <Button variant="outlined" onClick={this.hide}>Cancel</Button>
                  <Button variant="contained" type="submit">Save</Button>
                </DialogActions>
              </Grid>
            </form>
          </DialogContent>
        </Dialog>
      </>
    );
  }
}

const mapStateToProps = (state: any) => {
  console.log(state)
  return {
    list: state.student.list,
    currentIndex: state.student.currentIndex,
    is_open: state.student.is_open,
  };
};

const mapDispatchToProps: any = {
  studentDataAdd,
  update,
  updateIndex,
  popupOpen,
  popupClose,
};


const connector = connect(mapStateToProps, mapDispatchToProps);

type PropsFromRedux = ConnectedProps<typeof connector>;

type Props = PropsFromRedux;

export default connector(StudentPopup); 

