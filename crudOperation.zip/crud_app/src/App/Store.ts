import { configureStore } from '@reduxjs/toolkit';
import StudentReducer from '../Component/Student/StudentReducer'

export const store = configureStore({
    reducer:{
        student:StudentReducer
    }
    
});


/*
1. export const store: This line exports a constant named store that holds the Redux store object. The store object is responsible for managing the state of the application and handling actions and reducers.

2. configureStore({ reducer: { student: StudentReducer } }): This line configures the Redux store by passing an object to the configureStore function. The object contains a reducer property, which specifies the reducer function to be used for the "student" feature.
        ---reducer: { student: StudentReducer }: This part of the code specifies the reducers to be combined in the Redux store. In this case, there is a single reducer called StudentReducer, which is assigned to the "student" slice of the state. It means that the StudentReducer will handle state updates and actions related to the "student" feature.


*/